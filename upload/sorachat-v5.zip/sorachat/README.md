# SoraChat

iPad・スマホ向けのチャットアプリです。1対1とグループのトーク、リアクション、24時間ノート、音声通話、LINE風のプロフィールを備えます。データベースは Supabase のみを使い、Supabase Auth は使いません。

## 機能

- ログイン：仙人アカウントで続行、またはユーザー名とパスワードで登録・ログイン
- トーク：1対1とグループ（テキスト・画像、リアクション 👍 ❤️ 😂 😮 😢 🙏）
- グループ：管理者が名前変更・メンバー削除、全員がメンバー追加・退出
- ノート：60文字まで、24時間で消える一言。相手のプロフィールに表示
- 音声通話：1対1のみ。WebRTCで端末同士を直接つなぎ、音声はサーバーを通りません
- 通知：新着トークのWeb Push（オン・オフ可）
- プロフィール：LINE風（表示名、ユーザー名、ステータスメッセージ、画像）

## サーバー負荷について

- 新着はポーリングせず、Supabase Realtime（postgres_changes）で受け取ります。
- 通話の音声と映像は端末同士で直接やり取りし、サーバーは通話の開始・終了の信号を中継しません（Supabase Realtimeのブロードキャストを使用）。
- 送信・リアクション・メンバー操作だけがAPIリクエストになります。
- 未読などの一覧は、イベントを受けたときにまとめて再取得します（連続イベントは0.4秒まとめます）。保険として2分ごとにも再取得します。

## セットアップ

1. Supabase の SQL Editor で次の順に実行します（どれも再実行して問題ありません）。
   - `supabase/schema.sql`
   - `supabase/schema_v2.sql`
   - `supabase/schema_v3.sql`（プロフィールの連絡先・Web サイト）
   - `supabase/schema_v4.sql`（編集・送信取り消し・転送）
   - `supabase/schema_v5.sql`（送信の重複防止・過去ログの読み込み）
2. Supabase の Realtime が有効になっていることを確認します（既定で有効です）。
3. `.env.example` を `.env` にコピーして値を入れます。
   - `SUPABASE_URL` / `SUPABASE_SERVICE_ROLE_KEY` / `SUPABASE_ANON_KEY` / `SUPABASE_JWT_SECRET`（Settings → API にあります）は必須です。
   - 仙人アカウントは `SENNIN_*`、通知は VAPID キーを設定します。
4. `npm install` のあと、開発は `npm run dev`、本番は `npm run build` → `npm start` です。

## Render へのデプロイ

- Build Command: `npm install && npm run build`
- Start Command: `npm start`
- Health Check Path: `/api/health`
- 環境変数は `.env.example` と同じ名前で設定します。

## 通話についての注意

- 通話は STUN（Google の公開サーバー）だけを使います。会社や携帯回線などで直接つながらない場合は、TURN サーバーが必要です。TURN は通話の音声を中継するため、その分の帯域料金がかかります。必要になったら `call.ts` の `RTC_CONFIG` に TURN を追加してください。
- 相手に着信するのは、相手がアプリを開いているときだけです。閉じているときは、通知は届きますが通話は鳴りません。
- グループ通話は未対応です。

## 注意点

- iOS で通知を受けるには、Safari でホーム画面に追加して、そのアプリとして開く必要があります。
- 通話の着信を送る際の送信元は、アプリ側の情報をそのまま信頼しています。信頼できる範囲のユーザーで使ってください。
- ログイン試行は1分あたり20回までに制限しています。この制限はプロセス内の記録なので、複数インスタンスでは共有されません。
- ロゴとアイコンは SoraLink の流用です。`public/icons/icon-180.png` を差し替えてください。
- 旧版（DMだけのバージョン）の既存データは、そのまま使えます。schema_v2 は既存テーブルに列を追加するだけです。


## UI update notes

- 画面のデザインは Instagram のダイレクトメッセージ風に変更しました（`src/instagram.css`）。自分の吹き出しは青、相手は灰色で、連続メッセージはまとめて表示します。未読は青い点で示します。

- ライトテーマを初期設定にし、設定からライト / ダークを切り替えられます。選択したテーマはブラウザーに保存されます。
- プロフィール編集で連絡先と Web サイト URL を設定できます。
- ユーザー名検索は候補を表示し、QR モードは対応ブラウザーのカメラで SoraChat のユーザー QR を読み取ります。
- 追加したプロフィール項目を利用する前に、Supabase SQL Editor で `supabase/schema_v3.sql` を実行してください。
- Font Awesome と Inter フォントは CDN から読み込みます。QR コード画像は QRServer の生成 API を利用します。
