import { decryptText, encryptText } from "./crypto.js";
import { activeEndpoints, sendToUser } from "./hub.js";
import { removeImage } from "./media.js";
import { notifyRecipient } from "./push.js";
import { sb } from "./supabase.js";

export const UUID = /^[0-9a-f-]{36}$/i;
export const COLUMNS =
  "id, conversation_id, sender_id, kind, body, created_at, edited_at, deleted_at, forwarded, file_name, file_size, contact_user_id, reply_to_id";

export type Role = "owner" | "member";
export type Reaction = { emoji: string; count: number; mine: boolean };
export type MessageRow = {
  id: string;
  conversation_id: string;
  sender_id: string;
  kind: "text" | "image" | "file" | "contact";
  body: string | null;
  created_at: string;
  edited_at: string | null;
  deleted_at: string | null;
  forwarded: boolean;
  file_name: string | null;
  file_size: number | null;
  contact_user_id: string | null;
  reply_to_id: string | null;
};
export type ContactInfo = { id: string; username: string; displayName: string; hasAvatar: boolean };
export type Content =
  | { kind: "text"; body: string }
  | { kind: "image"; imagePath: string }
  | { kind: "file"; filePath: string; fileName: string; fileSize: number }
  | { kind: "contact"; contactUserId: string };

export function toMessage(
  row: MessageRow,
  reactions: Reaction[] = [],
  clientId: string | null = null,
  contact: ContactInfo | null = null
) {
  const deleted = row.deleted_at !== null;
  return {
    id: row.id,
    conversationId: row.conversation_id,
    senderId: row.sender_id,
    kind: row.kind,
    body: deleted ? null : decryptText(row.body),
    imageUrl: row.kind === "image" && !deleted ? `/api/dm/messages/${row.id}/image` : null,
    fileName: row.kind === "file" && !deleted ? row.file_name : null,
    fileSize: row.kind === "file" && !deleted ? row.file_size : null,
    fileUrl: row.kind === "file" && !deleted ? `/api/dm/messages/${row.id}/file` : null,
    contact: row.kind === "contact" && !deleted ? contact : null,
    createdAt: row.created_at,
    edited: row.edited_at !== null,
    deleted,
    forwarded: row.forwarded,
    replyToId: row.reply_to_id,
    reactions,
    clientId
  };
}

export async function membership(conversationId: string, userId: string): Promise<{ role: Role } | null> {
  if (!UUID.test(conversationId)) return null;
  const { data, error } = await sb
    .from("sc_members")
    .select("role")
    .eq("conversation_id", conversationId)
    .eq("user_id", userId)
    .maybeSingle();
  if (error) throw error;
  return data ? { role: data.role as Role } : null;
}

export async function memberIds(conversationId: string): Promise<string[]> {
  const { data, error } = await sb.from("sc_members").select("user_id").eq("conversation_id", conversationId);
  if (error) throw error;
  return (data ?? []).map((row: any) => row.user_id as string);
}

// 2人だけの「グループでない」会話を探す。なければ新しく作る（created は新しく作ったかどうか）。
// グループ（is_group = true）は絶対に返さない。旧DMは is_group が null のことがあるので null は1対1扱い。
export async function findOrCreateDm(me: string, other: string): Promise<{ id: string; created: boolean }> {
  const { data: mine, error: mineError } = await sb.from("sc_members").select("conversation_id").eq("user_id", me);
  if (mineError) throw mineError;
  const myIds = (mine ?? []).map((row: { conversation_id: string }) => row.conversation_id);

  if (myIds.length) {
    const { data: shared, error: sharedError } = await sb
      .from("sc_members")
      .select("conversation_id")
      .eq("user_id", other)
      .in("conversation_id", myIds);
    if (sharedError) throw sharedError;
    const sharedIds = (shared ?? []).map((row: { conversation_id: string }) => row.conversation_id);

    if (sharedIds.length) {
      const { data: convs, error: convsError } = await sb
        .from("sc_conversations")
        .select("id, is_group")
        .in("id", sharedIds);
      if (convsError) throw convsError;
      const candidates = (convs ?? []).filter((c: { is_group: boolean | null }) => c.is_group !== true).map((c: { id: string }) => c.id);

      if (candidates.length) {
        const { data: members, error: membersError } = await sb
          .from("sc_members")
          .select("conversation_id, user_id")
          .in("conversation_id", candidates);
        if (membersError) throw membersError;
        for (const id of candidates) {
          const people = (members ?? []).filter((m: { conversation_id: string }) => m.conversation_id === id);
          const ids = people.map((m: { user_id: string }) => m.user_id);
          if (ids.length === 2 && ids.includes(me) && ids.includes(other)) return { id, created: false };
        }
      }
    }
  }

  const { data: created, error: createError } = await sb
    .from("sc_conversations")
    .insert({ is_group: false })
    .select("id")
    .single();
  if (createError) throw createError;
  const { error: memberError } = await sb.from("sc_members").insert([
    { conversation_id: created.id, user_id: me },
    { conversation_id: created.id, user_id: other },
  ]);
  if (memberError) throw memberError;
  return { id: created.id as string, created: true };
}

export function summarize(rows: { user_id: string; emoji: string }[], viewer: string): Reaction[] {
  const map = new Map<string, Reaction>();
  for (const r of rows) {
    const entry = map.get(r.emoji) ?? { emoji: r.emoji, count: 0, mine: false };
    entry.count += 1;
    if (r.user_id === viewer) entry.mine = true;
    map.set(r.emoji, entry);
  }
  return [...map.values()];
}

// 会話の全メンバーへ同じイベントを送る（オンラインのみ。オフラインはDBに残るので後で取得できる）
export async function broadcastToConversation(conversationId: string, payload: unknown) {
  const members = await memberIds(conversationId);
  for (const uid of members) sendToUser(uid, payload);
}

export async function broadcastList(conversationId: string) {
  await broadcastToConversation(conversationId, { type: "list" });
}

export async function broadcastReactions(conversationId: string, messageId: string) {
  const [members, { data, error }] = await Promise.all([
    memberIds(conversationId),
    sb.from("sc_reactions").select("user_id, emoji").eq("message_id", messageId)
  ]);
  if (error) throw error;
  const rows = (data ?? []) as { user_id: string; emoji: string }[];
  for (const uid of members) {
    sendToUser(uid, { type: "reactions", conversationId, messageId, reactions: summarize(rows, uid) });
  }
}

// 返信先が同じ会話にあるかを確かめる（別の会話のメッセージへの返信は許さない）
export async function replyTargetOk(conversationId: string, replyToId: string | null | undefined): Promise<boolean> {
  if (!replyToId) return true;
  if (!UUID.test(replyToId)) return false;
  const { data, error } = await sb
    .from("sc_messages")
    .select("id")
    .eq("id", replyToId)
    .eq("conversation_id", conversationId)
    .maybeSingle();
  if (error) throw error;
  return Boolean(data);
}

async function notifyOffline(conversationId: string, senderId: string, members: string[], _preview: string) {
  // 送った本人以外の全員へ。画面を開いている端末だけは、その端末への通知を省く
  const others = members.filter((uid) => uid !== senderId);
  if (!others.length) return;
  const [{ data: sender }, { data: conv }] = await Promise.all([
    sb.from("sc_users").select("display_name").eq("id", senderId).maybeSingle(),
    sb.from("sc_conversations").select("is_group, title").eq("id", conversationId).maybeSingle()
  ]);
  const senderName = conv?.is_group
    ? `${sender?.display_name ?? "メンバー"}（${conv.title ?? "グループ"}）`
    : sender?.display_name ?? "新着メッセージ";
  for (const uid of others) {
    // 本文は通知（Apple/Google のプッシュサービス経由）に載せない
    void notifyRecipient({
      recipientId: uid,
      senderName,
      preview: "新しいメッセージがあります",
      conversationId,
      skipEndpoints: activeEndpoints(uid)
    });
  }
}

// 送信の流れ: 1) DBに保存 → 2) 会話メンバーのうちオンラインの人へWebSocketで即時配信
// → 3) オフラインの人はDB保存済みの内容をWeb Pushで通知（開いたときにDBから取得）
export async function insertMessage(
  conversationId: string,
  senderId: string,
  content: Content,
  preview: string,
  options: { forwarded?: boolean; clientId?: string | null; replyToId?: string | null } = {}
): Promise<MessageRow> {
  const clientId = options.clientId ?? null;

  // 再送（タイムアウト後のリトライなど）は、既に保存済みのメッセージをそのまま返す
  const findExisting = async () => {
    const { data, error } = await sb
      .from("sc_messages")
      .select(COLUMNS)
      .eq("conversation_id", conversationId)
      .eq("sender_id", senderId)
      .eq("client_id", clientId as string)
      .maybeSingle();
    if (error) throw error;
    return (data as MessageRow | null) ?? null;
  };
  if (clientId) {
    const existing = await findExisting();
    if (existing) return existing;
  }

  const now = new Date().toISOString();
  const shortPreview = preview.slice(0, 80);
  const none = {
    image_path: null,
    file_path: null,
    file_name: null,
    file_size: null,
    contact_user_id: null,
    reply_to_id: options.replyToId ?? null
  };
  const fields =
    content.kind === "text"
      ? { ...none, kind: "text", body: encryptText(content.body) }
      : content.kind === "image"
        ? { ...none, kind: "image", body: null, image_path: content.imagePath }
        : content.kind === "file"
          ? { ...none, kind: "file", body: null, file_path: content.filePath, file_name: content.fileName, file_size: content.fileSize }
          : { ...none, kind: "contact", body: null, contact_user_id: content.contactUserId };

  const { data, error } = await sb
    .from("sc_messages")
    .insert({
      conversation_id: conversationId,
      sender_id: senderId,
      created_at: now,
      forwarded: options.forwarded ?? false,
      client_id: clientId,
      ...fields
    })
    .select(COLUMNS)
    .single();
  if (error) {
    // 同時に2回届いた場合（一意制約に違反）は、先に保存された方を返す
    if (clientId && (error as { code?: string }).code === "23505") {
      const existing = await findExisting();
      if (existing) return existing;
    }
    throw error;
  }
  const row = data as MessageRow;

  const [members] = await Promise.all([
    memberIds(conversationId),
    sb
      .from("sc_conversations")
      .update({ last_message_at: now, last_preview: encryptText(shortPreview), last_sender_id: senderId })
      .eq("id", conversationId),
    sb.from("sc_members").update({ last_read_at: now }).eq("conversation_id", conversationId).eq("user_id", senderId)
  ]);

  const wire = toMessage(row, [], options.clientId ?? null);
  for (const uid of members) {
    sendToUser(uid, { type: "message", message: wire });
    sendToUser(uid, { type: "list" });
  }
  void notifyOffline(conversationId, senderId, members, shortPreview);
  return row;
}

// 画像・ファイルの実体は、どのメッセージからも参照されなくなったときに消す（転送で共有するため）
export async function removeImageIfUnused(path: string) {
  const { count } = await sb
    .from("sc_messages")
    .select("id", { count: "exact", head: true })
    .or(`image_path.eq.${path},file_path.eq.${path}`);
  if (!count) await removeImage(path);
}
