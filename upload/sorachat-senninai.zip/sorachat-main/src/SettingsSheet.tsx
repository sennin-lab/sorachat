import { useState } from "react";
import { ApiError, api, patch } from "./api";
import { Icon } from "./Icon";
import { disablePush, enablePush, testPush } from "./push";
import type { Me } from "./types";

// 設定（LINE の設定画面のように、項目をグループ分けして表示する）
export function SettingsSheet({
  me,
  theme,
  onThemeChange,
  onChange,
  onClose,
  onLogout
}: {
  me: Me;
  theme: "light" | "dark";
  onThemeChange: (theme: "light" | "dark") => void;
  onChange: (me: Me) => void;
  onClose: () => void;
  onLogout: () => void;
}) {
  const [notify, setNotify] = useState(me.notifyDm);
  const [ai, setAi] = useState(me.aiEnabled);
  const [status, setStatus] = useState("");
  const [testMessage, setTestMessage] = useState("");
  const [busy, setBusy] = useState(false);

  // senninai（AIチャット）のオン・オフ。オンにするとトーク一覧に「senninai」が出る
  const toggleAi = async (on: boolean) => {
    setBusy(true);
    setStatus("");
    setAi(on);
    try {
      onChange(await api<Me>("/api/me", patch({ aiEnabled: on })));
    } catch (err) {
      setAi(!on);
      setStatus(err instanceof ApiError ? err.message : "AI機能の設定を変更できませんでした。");
    } finally {
      setBusy(false);
    }
  };

  const toggleNotify = async (on: boolean) => {
    setBusy(true);
    setStatus("");
    setNotify(on);
    try {
      if (on) {
        // 許可の確認を先に出す（先に通信すると iOS で確認が出せなくなる）。失敗したら設定もオフのまま
        const result = await enablePush();
        if (!result.ok) {
          setNotify(false);
          setStatus(result.message);
          return;
        }
        onChange(await api<Me>("/api/me", patch({ notifyDm: true })));
      } else {
        onChange(await api<Me>("/api/me", patch({ notifyDm: false })));
        await disablePush();
      }
    } catch (err) {
      setNotify(!on);
      setStatus(err instanceof ApiError ? err.message : "通知の設定を変更できませんでした。");
    } finally {
      setBusy(false);
    }
  };

  const logout = async () => {
    await api("/api/auth/logout", { method: "POST" }).catch(() => undefined);
    onLogout();
  };

  return (
    <div className="page" role="dialog" aria-label="設定">
      <header className="page-bar">
        <button onClick={onClose} aria-label="戻る">
          <Icon name="back" size={26} />
        </button>
        <strong>設定</strong>
        <span />
      </header>

      <div className="section-label flush">
        <span>表示</span>
      </div>
      <div className="page-card">
        <label className="page-row">
          <span className="row-label">
            <span className="option-icon">
              <Icon name="moon" size={18} />
            </span>
            ダークモード
          </span>
          <input
            type="checkbox"
            className="switch"
            checked={theme === "dark"}
            onChange={(e) => onThemeChange(e.target.checked ? "dark" : "light")}
          />
        </label>
      </div>

      <div className="section-label flush">
        <span>AI</span>
      </div>
      <div className="page-card">
        <label className="page-row">
          <span className="row-label">
            <span className="option-icon">
              <Icon name="chat" size={18} />
            </span>
            senninai（AIチャット）
          </span>
          <input
            type="checkbox"
            className="switch"
            checked={ai}
            disabled={busy}
            onChange={(e) => void toggleAi(e.target.checked)}
          />
        </label>
      </div>
      <p className="notice center small">
        オンにすると、トーク一覧に「senninai」が出ます。グループでは「/senninai add」で参加、「/senninai ask 質問」で質問できます。
        話しかけた内容は、AIの応答のために外部サービス（UserLocal）へ送られます。
      </p>

      <div className="section-label flush">
        <span>通知</span>
      </div>
      <div className="page-card">
        <label className="page-row">
          <span className="row-label">
            <span className="option-icon">
              <Icon name="bell" size={18} />
            </span>
            新着メッセージの通知
          </span>
          <input
            type="checkbox"
            className="switch"
            checked={notify}
            disabled={busy}
            onChange={(e) => void toggleNotify(e.target.checked)}
          />
        </label>
      </div>

      {notify && (
        <div className="page-card">
          <button
            className="page-row"
            disabled={busy}
            onClick={async () => {
              setTestMessage("送信しています…");
              setTestMessage(await testPush());
            }}
          >
            <span>テスト通知を送る</span>
          </button>
        </div>
      )}
      {testMessage && <p className="notice center">{testMessage}</p>}

      <div className="section-label flush">
        <span>アカウント</span>
      </div>
      <div className="page-card">
        <button className="page-row danger" onClick={() => void logout()}>
          <span>ログアウト</span>
        </button>
      </div>

      {status && <p className="notice center error shake">{status}</p>}
    </div>
  );
}
